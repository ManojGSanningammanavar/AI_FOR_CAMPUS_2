
  # AI Campus Optimization Dashboard

  This is a code bundle for AI Campus Optimization Dashboard. The original project is available at https://www.figma.com/design/blw1hnBmmX5ynst6NAdGgv/AI-Campus-Optimization-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  