import { motion } from 'motion/react';
import { TrendingUp, Brain } from 'lucide-react';
import { DashboardHeader } from './components/DashboardHeader';
import { KPIMetricsRow } from './components/KPIMetricsRow';
import { ModuleCard } from './components/ModuleCard';
import { EnvironmentalModule } from './components/EnvironmentalModule';
import { PredictiveAlertsPanel } from './components/PredictiveAlertsPanel';
import { EnvironmentalMetrics } from './components/EnvironmentalMetrics';
import { ChatbotAssistant } from './components/ChatbotAssistant';

export default function App() {
  const resourceOptimizationBenefits = [
    { label: '40% Efficiency Gain', highlight: true },
    { label: 'Smart Scheduling', highlight: false },
    { label: 'Dynamic Allocation', highlight: false },
    { label: 'Cost Reduction', highlight: false }
  ];

  const predictiveIntelligenceBenefits = [
    { label: '95% Issue Prevention', highlight: true },
    { label: 'Early Anomaly Detection', highlight: false },
    { label: 'Pattern Recognition', highlight: false },
    { label: 'Risk Assessment', highlight: false }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-900 to-blue-900 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <motion.div
          className="absolute top-20 left-20 w-72 h-72 bg-indigo-500/10 rounded-full blur-3xl"
          animate={{ 
            x: [0, 100, 0],
            y: [0, -50, 0],
            scale: [1, 1.2, 1]
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute bottom-20 right-20 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl"
          animate={{ 
            x: [0, -80, 0],
            y: [0, 60, 0],
            scale: [1, 0.8, 1]
          }}
          transition={{ duration: 25, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute top-1/2 left-1/2 w-64 h-64 bg-violet-500/10 rounded-full blur-3xl"
          animate={{ 
            x: [-50, 50, -50],
            y: [-30, 30, -30],
            scale: [0.8, 1.1, 0.8]
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute top-40 right-40 w-48 h-48 bg-green-500/10 rounded-full blur-3xl"
          animate={{ 
            x: [0, -60, 0],
            y: [0, 40, 0],
            scale: [1, 0.9, 1]
          }}
          transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
        />
      </div>

      {/* Grid pattern overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />

      {/* Main content */}
      <div className="relative z-10 container mx-auto px-6 py-8 max-w-7xl">
        <DashboardHeader />
        
        {/* KPI Metrics Row */}
        <KPIMetricsRow />
        
        {/* Main AI Modules - Clean 3-column layout */}
        <motion.div
          className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          {/* Resource Optimization Module */}
          <ModuleCard
            title="Resource Optimization"
            subtitle="Reinforcement Learning"
            description="AI-driven scheduling and allocation ensures optimal use of classrooms, equipment, and human resources."
            icon={TrendingUp}
            benefits={resourceOptimizationBenefits}
            accentColor="green"
            progressValue={40}
            progressLabel="Efficiency Gain"
          />

          {/* Predictive Intelligence Module */}
          <ModuleCard
            title="Predictive Intelligence"
            subtitle="Graph Neural Networks"
            description="Advanced AI detects patterns across all campus systems to predict and prevent issues before they occur."
            icon={Brain}
            benefits={predictiveIntelligenceBenefits}
            accentColor="blue"
            progressValue={95}
            progressLabel="Issue Prevention"
          />

          {/* Environmental Monitoring Module */}
          <EnvironmentalModule />
        </motion.div>

        {/* Additional Information Panels */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <PredictiveAlertsPanel />
          <EnvironmentalMetrics />
        </div>
      </div>

      {/* Chatbot Assistant */}
      <ChatbotAssistant />
    </div>
  );
}