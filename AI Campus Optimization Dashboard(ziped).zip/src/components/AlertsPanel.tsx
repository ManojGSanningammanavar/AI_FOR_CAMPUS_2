import { motion } from 'motion/react';
import { AlertTriangle, CheckCircle, Clock, TrendingDown } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';

const alerts = [
  {
    id: 1,
    type: 'warning',
    title: 'Room B-204 AC malfunction predicted in 2 hours',
    time: '2 min ago',
    priority: 'high'
  },
  {
    id: 2,
    type: 'success',
    title: 'Energy optimization completed for Building C',
    time: '15 min ago',
    priority: 'medium'
  },
  {
    id: 3,
    type: 'info',
    title: 'Network maintenance scheduled for tomorrow',
    time: '1 hour ago',
    priority: 'low'
  },
  {
    id: 4,
    type: 'warning',
    title: 'Unusual power consumption detected in Lab A',
    time: '2 hours ago',
    priority: 'medium'
  }
];

export function AlertsPanel() {
  const getIcon = (type: string) => {
    switch (type) {
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-orange-400" />;
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-400" />;
      case 'info':
        return <Clock className="h-4 w-4 text-blue-400" />;
      default:
        return <TrendingDown className="h-4 w-4 text-red-400" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-500/20 text-red-400 border-red-500/50';
      case 'medium':
        return 'bg-orange-500/20 text-orange-400 border-orange-500/50';
      case 'low':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/50';
      default:
        return 'bg-slate-500/20 text-slate-400 border-slate-500/50';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.4 }}
    >
      <Card className="p-6 bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur-sm border-slate-700/50">
        <div className="mb-6">
          <h3 className="text-white mb-2">Predictive Alerts</h3>
          <p className="text-slate-400 text-sm">AI-powered early warning system</p>
        </div>
        
        <div className="space-y-4">
          {alerts.map((alert, index) => (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className="flex items-start gap-3 p-3 rounded-lg bg-slate-700/30 border border-slate-600/50 hover:border-slate-500/70 transition-colors duration-200"
            >
              <div className="mt-0.5">
                {getIcon(alert.type)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-slate-200 text-sm mb-1">{alert.title}</p>
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 text-xs">{alert.time}</span>
                  <Badge className={`text-xs ${getPriorityColor(alert.priority)}`}>
                    {alert.priority}
                  </Badge>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </Card>
    </motion.div>
  );
}