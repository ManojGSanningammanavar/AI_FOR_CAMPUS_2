import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { MessageCircle, Send, X, Bot, User } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';

const examplePrompts = [
  "Suggest optimal room allocation for tomorrow",
  "Show today's carbon footprint",
  "Explain energy optimization in simple terms",
  "What are the current sustainability metrics?"
];

const mockResponses = {
  "Suggest optimal room allocation for tomorrow": "Based on current booking patterns and historical data, I recommend allocating Lab A (85% utilization) for high-capacity classes, while Studio D can handle smaller workshops. Block B should reserve rooms 201-204 for flexible scheduling.",
  "Show today's carbon footprint": "Today's carbon footprint is 15% below average! Energy consumption is optimized at 92% efficiency, with renewable energy covering 68% of campus needs. The Environmental Monitoring system shows we're on track for our 30% reduction target.",
  "Explain energy optimization in simple terms": "Our AI system learns from daily patterns - when rooms are used, which equipment runs when, and weather conditions. It automatically adjusts heating, lighting, and equipment schedules to save energy while keeping everyone comfortable.",
  "What are the current sustainability metrics?": "🌱 Current metrics: Energy Efficiency 92%, Sustainability Score 88%, Carbon footprint reduced by 30% this month. Air quality is excellent across all monitored areas."
};

export function ChatbotAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Array<{text: string, isUser: boolean}>>([
    { text: "Hi! I'm your AI Campus Assistant. How can I help you optimize your campus today?", isUser: false }
  ]);
  const [inputValue, setInputValue] = useState('');

  const handleSendMessage = (message: string) => {
    if (!message.trim()) return;
    
    setMessages(prev => [...prev, { text: message, isUser: true }]);
    setInputValue('');
    
    // Simulate AI response
    setTimeout(() => {
      const response = mockResponses[message as keyof typeof mockResponses] || 
        "I understand your question. Let me analyze the current campus data and provide you with insights based on our AI monitoring systems.";
      setMessages(prev => [...prev, { text: response, isUser: false }]);
    }, 1000);
  };

  const handlePromptClick = (prompt: string) => {
    handleSendMessage(prompt);
  };

  return (
    <>
      {/* Floating Chat Button */}
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, delay: 1 }}
      >
        <motion.button
          onClick={() => setIsOpen(true)}
          className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 border border-indigo-400/30"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          animate={{
            boxShadow: [
              "0 0 20px rgba(59, 130, 246, 0.3)",
              "0 0 30px rgba(79, 70, 229, 0.4)",
              "0 0 20px rgba(59, 130, 246, 0.3)"
            ]
          }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <MessageCircle className="h-8 w-8 text-white" />
        </motion.button>
      </motion.div>

      {/* Chat Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed bottom-6 right-6 z-50 w-96 max-w-[calc(100vw-3rem)]"
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="bg-gradient-to-br from-slate-800/95 to-slate-900/95 backdrop-blur-lg border-slate-700/50 shadow-2xl">
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-slate-700/50">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-full flex items-center justify-center">
                    <Bot className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-white text-sm">AI Campus Assistant</h3>
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
                      <span className="text-slate-400 text-xs">Online</span>
                    </div>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsOpen(false)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              {/* Messages */}
              <div className="h-80 overflow-y-auto p-4 space-y-4">
                {messages.map((message, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`flex items-start gap-2 max-w-[80%] ${message.isUser ? 'flex-row-reverse' : ''}`}>
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                        message.isUser 
                          ? 'bg-blue-500' 
                          : 'bg-gradient-to-br from-indigo-500 to-blue-600'
                      }`}>
                        {message.isUser ? (
                          <User className="h-3 w-3 text-white" />
                        ) : (
                          <Bot className="h-3 w-3 text-white" />
                        )}
                      </div>
                      <div className={`p-3 rounded-lg ${
                        message.isUser 
                          ? 'bg-blue-500/20 text-blue-100 border border-blue-500/30' 
                          : 'bg-slate-700/50 text-slate-200 border border-slate-600/50'
                      }`}>
                        <p className="text-sm">{message.text}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}

                {/* Example Prompts */}
                {messages.length === 1 && (
                  <div className="space-y-2">
                    <p className="text-slate-400 text-xs">Try asking:</p>
                    {examplePrompts.map((prompt, index) => (
                      <motion.button
                        key={index}
                        onClick={() => handlePromptClick(prompt)}
                        className="w-full text-left p-2 rounded-lg bg-slate-700/30 border border-slate-600/50 text-slate-300 text-xs hover:bg-slate-600/30 hover:border-slate-500/70 transition-all duration-200"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        "{prompt}"
                      </motion.button>
                    ))}
                  </div>
                )}
              </div>

              {/* Input */}
              <div className="p-4 border-t border-slate-700/50">
                <div className="flex gap-2">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Ask me anything about campus optimization..."
                    className="flex-1 bg-slate-700/30 border-slate-600/50 text-white placeholder-slate-400"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        handleSendMessage(inputValue);
                      }
                    }}
                  />
                  <Button
                    onClick={() => handleSendMessage(inputValue)}
                    size="sm"
                    className="bg-gradient-to-r from-indigo-500 to-blue-600 hover:from-indigo-600 hover:to-blue-700"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}