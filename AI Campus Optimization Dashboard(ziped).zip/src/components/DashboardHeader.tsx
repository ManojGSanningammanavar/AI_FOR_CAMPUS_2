import { motion } from 'motion/react';
import { Brain, Zap } from 'lucide-react';

export function DashboardHeader() {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className="text-center mb-8"
    >
      <div className="flex items-center justify-center gap-3 mb-4">
        <motion.div
          className="p-2 rounded-lg bg-gradient-to-br from-indigo-500/20 to-blue-500/20 border border-indigo-500/30"
          whileHover={{ scale: 1.05, rotate: 5 }}
          transition={{ duration: 0.2 }}
        >
          <Brain className="h-7 w-7 text-indigo-400" />
        </motion.div>
        <motion.h1 
          className="text-3xl bg-gradient-to-r from-white via-indigo-200 to-blue-300 bg-clip-text text-transparent"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
        >
          AI Campus Intelligence Dashboard
        </motion.h1>
        <motion.div
          className="p-2 rounded-lg bg-gradient-to-br from-blue-500/20 to-indigo-500/20 border border-blue-500/30"
          whileHover={{ scale: 1.05, rotate: -5 }}
          transition={{ duration: 0.2 }}
        >
          <Zap className="h-7 w-7 text-blue-400" />
        </motion.div>
      </div>
      
      <motion.p 
        className="text-slate-300 max-w-3xl mx-auto leading-relaxed mb-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 0.4 }}
      >
        Unified optimization, prediction, and sustainability monitoring for smarter campuses.
      </motion.p>
      
      <motion.div
        className="flex items-center justify-center gap-6"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 0.6 }}
      >
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></div>
          <span className="text-slate-400 text-xs">System Online</span>
        </div>
        <div className="w-px h-3 bg-slate-600"></div>
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></div>
          <span className="text-slate-400 text-xs">AI Processing</span>
        </div>
        <div className="w-px h-3 bg-slate-600"></div>
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse"></div>
          <span className="text-slate-400 text-xs">Real-time Data</span>
        </div>
      </motion.div>
    </motion.div>
  );
}