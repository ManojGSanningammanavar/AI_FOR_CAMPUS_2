import { motion } from 'motion/react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Card } from './ui/card';

const energyData = [
  { time: '00:00', actual: 130, optimal: 125, predicted: 135 },
  { time: '04:00', actual: 85, optimal: 80, predicted: 90 },
  { time: '08:00', actual: 195, optimal: 185, predicted: 200 },
  { time: '12:00', actual: 220, optimal: 215, predicted: 225 },
  { time: '16:00', actual: 250, optimal: 240, predicted: 255 },
  { time: '20:00', actual: 160, optimal: 150, predicted: 165 },
];

export function EnergyChart() {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6, delay: 0.2 }}
    >
      <Card className="p-6 bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur-sm border-slate-700/50">
        <div className="mb-6">
          <h3 className="text-white mb-2">Energy Consumption & Predictions</h3>
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-400"></div>
              <span className="text-slate-400">Actual: 160</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-400"></div>
              <span className="text-slate-400">Optimal: 150</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-400"></div>
              <span className="text-slate-400">Predicted: 165</span>
            </div>
          </div>
        </div>
        
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={energyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis 
                dataKey="time" 
                stroke="#9CA3AF"
                fontSize={12}
              />
              <YAxis 
                stroke="#9CA3AF"
                fontSize={12}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1e293b',
                  border: '1px solid #475569',
                  borderRadius: '8px',
                  color: '#f1f5f9'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="actual" 
                stroke="#60a5fa" 
                strokeWidth={2}
                dot={{ fill: '#60a5fa', strokeWidth: 2, r: 4 }}
              />
              <Line 
                type="monotone" 
                dataKey="optimal" 
                stroke="#34d399" 
                strokeWidth={2}
                dot={{ fill: '#34d399', strokeWidth: 2, r: 4 }}
              />
              <Line 
                type="monotone" 
                dataKey="predicted" 
                stroke="#f87171" 
                strokeWidth={2}
                strokeDasharray="5 5"
                dot={{ fill: '#f87171', strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </motion.div>
  );
}