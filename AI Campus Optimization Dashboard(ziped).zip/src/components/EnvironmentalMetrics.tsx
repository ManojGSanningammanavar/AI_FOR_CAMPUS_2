import { motion } from 'motion/react';
import { Thermometer, Droplets, Wind, Leaf } from 'lucide-react';
import { Card } from './ui/card';

const environmentalData = [
  {
    metric: 'Temperature',
    value: '22°C',
    status: 'optimal',
    icon: Thermometer,
    color: 'text-green-400',
    bgColor: 'bg-green-500/20'
  },
  {
    metric: 'Humidity',
    value: '45%',
    status: 'good',
    icon: Droplets,
    color: 'text-blue-400',
    bgColor: 'bg-blue-500/20'
  },
  {
    metric: 'Air Quality',
    value: 'Good',
    status: 'excellent',
    icon: Wind,
    color: 'text-green-400',
    bgColor: 'bg-green-500/20'
  },
  {
    metric: 'CO₂ Level',
    value: '420 ppm',
    status: 'normal',
    icon: Leaf,
    color: 'text-emerald-400',
    bgColor: 'bg-emerald-500/20'
  }
];

export function EnvironmentalMetrics() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.5 }}
    >
      <Card className="p-6 bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur-sm border-slate-700/50">
        <div className="mb-6">
          <h3 className="text-white mb-2">Environmental Metrics</h3>
          <p className="text-slate-400 text-sm">Real-time campus environment tracking</p>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          {environmentalData.map((item, index) => (
            <motion.div
              key={item.metric}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              whileHover={{ scale: 1.02, y: -2 }}
              className={`p-4 rounded-lg border border-slate-600/50 transition-all duration-300 hover:border-slate-500/70 ${item.bgColor}`}
            >
              <div className="flex items-center gap-3 mb-3">
                <item.icon className={`h-5 w-5 ${item.color}`} />
                <span className="text-slate-300 text-sm">{item.metric}</span>
              </div>
              <div className="text-xl text-white mb-2">{item.value}</div>
              <div className={`text-xs px-2 py-1 rounded-full inline-flex items-center gap-1 ${
                item.status === 'optimal' || item.status === 'excellent' 
                  ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
                  : item.status === 'good' || item.status === 'normal'
                  ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                  : 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
              }`}>
                <motion.div
                  className="w-1.5 h-1.5 rounded-full bg-current"
                  animate={{ scale: [1, 1.3, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
                {item.status}
              </div>
            </motion.div>
          ))}
        </div>
      </Card>
    </motion.div>
  );
}