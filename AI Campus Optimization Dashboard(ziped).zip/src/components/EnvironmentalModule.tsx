import { motion } from 'motion/react';
import { Leaf } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const benefits = [
  { label: '30% Energy Savings', highlight: true },
  { label: 'Water Optimization', highlight: false },
  { label: 'Biodiversity Tracking', highlight: false },
  { label: 'Carbon Footprint', highlight: false }
];

const energySavingsData = [
  { month: 'Mar', savings: 20 },
  { month: 'Apr', savings: 25 },
  { month: 'May', savings: 28 },
  { month: 'Jun', savings: 30 }
];

const carbonData = [
  { name: 'Reduced', value: 65, color: '#10b981' },
  { name: 'Remaining', value: 35, color: '#475569' }
];

export function EnvironmentalModule() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      whileHover={{ 
        y: -4,
        transition: { duration: 0.2 } 
      }}
      className="h-full"
    >
      <Card className="h-full bg-gradient-to-br from-slate-800/95 to-green-900/30 backdrop-blur-sm border-2 border-green-500/40 hover:shadow-green-500/20 hover:shadow-xl transition-all duration-300 relative overflow-hidden min-h-[520px]">
        <div className="relative p-6 h-full flex flex-col">
          {/* Header */}
          <div className="mb-6">
            <div className="flex items-center gap-4 mb-4">
              <motion.div 
                className="p-3 rounded-xl bg-green-500/20 border border-green-500/40"
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.2 }}
              >
                <Leaf className="h-8 w-8 text-green-400" />
              </motion.div>
              <div className="flex-1">
                <h3 className="text-white text-xl mb-2">Environmental Monitoring</h3>
                <Badge 
                  variant="secondary" 
                  className="bg-green-500/15 border-green-500/30 text-white border px-3 py-1 text-xs"
                >
                  Ecosystem Intelligence
                </Badge>
              </div>
            </div>
            <p className="text-slate-300 leading-relaxed text-sm">Real-time tracking of campus greenery, energy usage, and environmental health for sustainable operations.</p>
          </div>

          {/* Charts Section */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            {/* Energy Savings Trend */}
            <div className="bg-slate-700/20 rounded-lg p-3">
              <h4 className="text-slate-300 text-xs mb-2">Energy Savings Trend</h4>
              <div className="h-24">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={energySavingsData}>
                    <CartesianGrid strokeDasharray="2 2" stroke="#374151" opacity={0.3} />
                    <XAxis 
                      dataKey="month" 
                      stroke="#9CA3AF"
                      fontSize={8}
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis 
                      stroke="#9CA3AF"
                      fontSize={8}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="savings" 
                      stroke="#10b981" 
                      strokeWidth={2}
                      dot={{ fill: '#10b981', strokeWidth: 2, r: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Carbon Footprint Analysis */}
            <div className="bg-slate-700/20 rounded-lg p-3">
              <h4 className="text-slate-300 text-xs mb-2">Carbon Footprint</h4>
              <div className="h-24 flex items-center justify-center">
                <ResponsiveContainer width="60%" height="100%">
                  <PieChart>
                    <Pie
                      data={carbonData}
                      cx="50%"
                      cy="50%"
                      innerRadius={12}
                      outerRadius={30}
                      dataKey="value"
                    >
                      {carbonData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Benefits Grid */}
          <div className="grid grid-cols-2 gap-3 mt-auto">
            {benefits.map((benefit, index) => (
              <motion.div
                key={benefit.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: 0.3 + index * 0.1 }}
                whileHover={{ scale: 1.02 }}
              >
                <div className={`p-3 rounded-lg border transition-all duration-200 text-center ${
                  benefit.highlight 
                    ? 'bg-green-500/20 border-green-500/40 text-green-400' 
                    : 'bg-slate-700/30 border-slate-600/50 text-slate-300 hover:bg-slate-600/40'
                }`}>
                  <span className="text-xs block">{benefit.label}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </Card>
    </motion.div>
  );
}