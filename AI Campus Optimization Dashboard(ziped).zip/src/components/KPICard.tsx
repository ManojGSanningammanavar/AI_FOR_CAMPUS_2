import { motion } from 'motion/react';
import { LucideIcon } from 'lucide-react';
import { Card } from './ui/card';

interface KPICardProps {
  title: string;
  value: string;
  icon: LucideIcon;
  color: 'green' | 'blue' | 'purple' | 'orange';
  progress: number;
}

export function KPICard({ title, value, icon: Icon, color, progress }: KPICardProps) {
  const colorStyles = {
    green: {
      iconColor: 'text-green-400',
      progressColor: 'bg-green-500',
      bgColor: 'from-green-500/10 to-emerald-500/5'
    },
    blue: {
      iconColor: 'text-blue-400',
      progressColor: 'bg-blue-500',
      bgColor: 'from-blue-500/10 to-indigo-500/5'
    },
    purple: {
      iconColor: 'text-purple-400',
      progressColor: 'bg-purple-500',
      bgColor: 'from-purple-500/10 to-violet-500/5'
    },
    orange: {
      iconColor: 'text-orange-400',
      progressColor: 'bg-orange-500',
      bgColor: 'from-orange-500/10 to-amber-500/5'
    }
  };

  const styles = colorStyles[color];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ scale: 1.02 }}
    >
      <Card className={`p-6 bg-gradient-to-br ${styles.bgColor} backdrop-blur-sm border-slate-700/50 hover:border-slate-600/70 transition-all duration-300`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-slate-400 text-sm mb-1">{title}</p>
            <p className="text-2xl text-white">{value}</p>
          </div>
          <div className={`p-2 rounded-lg bg-slate-800/50`}>
            <Icon className={`h-6 w-6 ${styles.iconColor}`} />
          </div>
        </div>
        
        {/* Progress bar */}
        <div className="w-full bg-slate-700/30 rounded-full h-2">
          <motion.div
            className={`h-2 rounded-full ${styles.progressColor}`}
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 1.5, ease: "easeOut" }}
          />
        </div>
      </Card>
    </motion.div>
  );
}