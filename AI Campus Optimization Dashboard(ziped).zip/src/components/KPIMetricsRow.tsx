import { motion } from 'motion/react';
import { Battery, Users, Wifi, Leaf } from 'lucide-react';
import { Card } from './ui/card';
import { CircularProgress } from './CircularProgress';

const metrics = [
  {
    title: 'Energy Efficiency',
    value: 92,
    icon: Battery,
    color: '#10b981',
    type: 'circular'
  },
  {
    title: 'Room Utilization',
    value: 73,
    icon: Users,
    color: '#3b82f6',
    type: 'bar'
  },
  {
    title: 'Network Health',
    value: 98,
    icon: Wifi,
    color: '#8b5cf6',
    type: 'status'
  },
  {
    title: 'Sustainability Score',
    value: 88,
    icon: Leaf,
    color: '#f59e0b',
    type: 'circular'
  }
];

export function KPIMetricsRow() {
  return (
    <motion.div
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-10"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.2 }}
    >
      {metrics.map((metric, index) => (
        <motion.div
          key={metric.title}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.1 * index }}
          whileHover={{ y: -2, scale: 1.01 }}
        >
          <Card className="p-4 bg-gradient-to-br from-slate-800/90 to-slate-900/90 backdrop-blur-sm border-slate-700/50 hover:border-slate-600/70 transition-all duration-300 h-32">
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className="text-slate-400 text-xs mb-1">{metric.title}</p>
                <p className="text-xl text-white">{metric.value}%</p>
              </div>
              <div className="p-1.5 rounded-lg bg-slate-700/50">
                <metric.icon className="h-4 w-4" style={{ color: metric.color }} />
              </div>
            </div>
            
            {metric.type === 'circular' && (
              <div className="flex justify-center">
                <div className="scale-50 -mt-2">
                  <CircularProgress
                    value={metric.value}
                    label=""
                    color={metric.color}
                  />
                </div>
              </div>
            )}
            
            {metric.type === 'bar' && (
              <div className="w-full bg-slate-700/30 rounded-full h-1.5">
                <motion.div
                  className="h-1.5 rounded-full"
                  style={{ backgroundColor: metric.color }}
                  initial={{ width: 0 }}
                  animate={{ width: `${metric.value}%` }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                />
              </div>
            )}
            
            {metric.type === 'status' && (
              <div className="flex items-center gap-2">
                <motion.div
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: metric.color }}
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
                <span className="text-slate-300 text-xs">Excellent</span>
              </div>
            )}
          </Card>
        </motion.div>
      ))}
    </motion.div>
  );
}