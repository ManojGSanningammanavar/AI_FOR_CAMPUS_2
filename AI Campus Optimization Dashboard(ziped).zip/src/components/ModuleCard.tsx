import { motion } from 'motion/react';
import { LucideIcon } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { CircularProgress } from './CircularProgress';

interface Benefit {
  label: string;
  highlight?: boolean;
}

interface ModuleCardProps {
  title: string;
  subtitle: string;
  description: string;
  icon: LucideIcon;
  benefits: Benefit[];
  accentColor: 'green' | 'blue';
  progressValue?: number;
  progressLabel?: string;
}

export function ModuleCard({ 
  title, 
  subtitle, 
  description, 
  icon: Icon, 
  benefits, 
  accentColor,
  progressValue,
  progressLabel
}: ModuleCardProps) {
  const accentStyles = {
    green: {
      iconBg: 'bg-green-500/20',
      iconColor: 'text-green-400',
      border: 'border-green-500/40',
      glow: 'shadow-green-500/20',
      progressColor: '#10b981',
      cardBg: 'from-slate-800/95 to-green-900/30',
      tagBg: 'bg-green-500/15 border-green-500/30'
    },
    blue: {
      iconBg: 'bg-blue-500/20',
      iconColor: 'text-blue-400',
      border: 'border-blue-500/40',
      glow: 'shadow-blue-500/20',
      progressColor: '#3b82f6',
      cardBg: 'from-slate-800/95 to-blue-900/30',
      tagBg: 'bg-blue-500/15 border-blue-500/30'
    }
  };

  const styles = accentStyles[accentColor];

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      whileHover={{ 
        y: -4, 
        transition: { duration: 0.2 } 
      }}
      className="h-full"
    >
      <Card className={`h-full bg-gradient-to-br ${styles.cardBg} backdrop-blur-sm border-2 ${styles.border} hover:${styles.glow} hover:shadow-xl transition-all duration-300 relative overflow-hidden min-h-[520px]`}>
        <div className="relative p-6 h-full flex flex-col">
          {/* Header with Icon and Title */}
          <div className="mb-6">
            <div className="flex items-center gap-4 mb-4">
              <motion.div 
                className={`p-3 rounded-xl ${styles.iconBg} border ${styles.border}`}
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.2 }}
              >
                <Icon className={`h-8 w-8 ${styles.iconColor}`} />
              </motion.div>
              <div className="flex-1">
                <h3 className="text-white text-xl mb-2">{title}</h3>
                <Badge 
                  variant="secondary" 
                  className={`${styles.tagBg} text-white border px-3 py-1 text-xs`}
                >
                  {subtitle}
                </Badge>
              </div>
            </div>
            <p className="text-slate-300 leading-relaxed text-sm">{description}</p>
          </div>

          {/* Circular Progress Chart */}
          {progressValue && progressLabel && (
            <div className="flex justify-center mb-6">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                <div className="scale-90">
                  <CircularProgress 
                    value={progressValue}
                    label={progressLabel}
                    color={styles.progressColor}
                  />
                </div>
              </motion.div>
            </div>
          )}

          {/* Benefits Grid */}
          <div className="grid grid-cols-2 gap-3 mt-auto">
            {benefits.map((benefit, index) => (
              <motion.div
                key={benefit.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: 0.3 + index * 0.1 }}
                whileHover={{ scale: 1.02 }}
              >
                <div className={`p-3 rounded-lg border transition-all duration-200 text-center ${
                  benefit.highlight 
                    ? `${styles.iconBg} ${styles.border} ${styles.iconColor}` 
                    : 'bg-slate-700/30 border-slate-600/50 text-slate-300 hover:bg-slate-600/40'
                }`}>
                  <span className="text-xs block">{benefit.label}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </Card>
    </motion.div>
  );
}