import { motion } from 'motion/react';
import { AlertTriangle, AlertCircle, Info, CheckCircle } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';

const alerts = [
  {
    id: 1,
    type: 'critical',
    title: 'Timetable conflict detected in Block B next week',
    description: 'Overlapping classes scheduled for Room B-204',
    time: '2 min ago',
    priority: 'critical',
    icon: AlertTriangle
  },
  {
    id: 2,
    type: 'warning',
    title: 'HVAC system maintenance required',
    description: 'Building C air conditioning efficiency dropping',
    time: '15 min ago',
    priority: 'high',
    icon: AlertCircle
  },
  {
    id: 3,
    type: 'info',
    title: 'Energy optimization completed successfully',
    description: '12% reduction in power consumption achieved',
    time: '1 hour ago',
    priority: 'low',
    icon: CheckCircle
  },
  {
    id: 4,
    type: 'warning',
    title: 'Network bandwidth approaching limit',
    description: 'Consider upgrading capacity for Lab areas',
    time: '2 hours ago',
    priority: 'medium',
    icon: Info
  }
];

export function PredictiveAlertsPanel() {
  const getAlertColors = (type: string) => {
    switch (type) {
      case 'critical':
        return {
          border: 'border-red-500/50',
          bg: 'bg-red-500/10',
          icon: 'text-red-400',
          badge: 'bg-red-500/20 text-red-400 border-red-500/50'
        };
      case 'warning':
        return {
          border: 'border-orange-500/50',
          bg: 'bg-orange-500/10',
          icon: 'text-orange-400',
          badge: 'bg-orange-500/20 text-orange-400 border-orange-500/50'
        };
      case 'info':
        return {
          border: 'border-green-500/50',
          bg: 'bg-green-500/10',
          icon: 'text-green-400',
          badge: 'bg-green-500/20 text-green-400 border-green-500/50'
        };
      default:
        return {
          border: 'border-blue-500/50',
          bg: 'bg-blue-500/10',
          icon: 'text-blue-400',
          badge: 'bg-blue-500/20 text-blue-400 border-blue-500/50'
        };
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.4 }}
    >
      <Card className="p-6 bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur-sm border-slate-700/50">
        <div className="mb-6">
          <h3 className="text-white mb-2">Predictive Alerts</h3>
          <p className="text-slate-400 text-sm">AI-powered early warning system</p>
        </div>
        
        <div className="space-y-4 max-h-80 overflow-y-auto">
          {alerts.map((alert, index) => {
            const colors = getAlertColors(alert.type);
            const IconComponent = alert.icon;
            
            return (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className={`p-4 rounded-lg border ${colors.border} ${colors.bg} hover:bg-opacity-20 transition-all duration-200`}
              >
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">
                    <IconComponent className={`h-5 w-5 ${colors.icon}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-slate-200 text-sm">{alert.title}</h4>
                      <Badge className={`text-xs ${colors.badge}`}>
                        {alert.priority}
                      </Badge>
                    </div>
                    <p className="text-slate-400 text-xs mb-2">{alert.description}</p>
                    <span className="text-slate-500 text-xs">{alert.time}</span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </Card>
    </motion.div>
  );
}