
  # Digital Xerox Ordering System

  This is a code bundle for Digital Xerox Ordering System. The original project is available at https://www.figma.com/design/JIPWFQKGLKP4qtgP1osanv/Digital-Xerox-Ordering-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  