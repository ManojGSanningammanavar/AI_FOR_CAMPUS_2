import { useState } from 'react';
import { Button } from './components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { FileText, Upload, Search, BarChart3, Clock, CheckCircle, Users } from 'lucide-react';
import { UploadDocument } from './components/UploadDocument';
import { OrderTracking } from './components/OrderTracking';
import { AdminDashboard } from './components/AdminDashboard';
import { AppProvider, useApp } from './contexts/AppContext';
import { Toaster } from './components/ui/sonner';

type ViewType = 'home' | 'upload' | 'tracking' | 'admin';

function AppContent() {
  const [currentView, setCurrentView] = useState<ViewType>('home');
  const [trackingOrderId, setTrackingOrderId] = useState<string>('');
  const { state } = useApp();

  const handleTrackOrder = (orderId?: string) => {
    if (orderId) {
      setTrackingOrderId(orderId);
    }
    setCurrentView('tracking');
  };

  const handleOrderCompleted = (orderId: string) => {
    setTrackingOrderId(orderId);
    setCurrentView('tracking');
  };

  const renderCurrentView = () => {
    switch (currentView) {
      case 'upload':
        return <UploadDocument 
          onBack={() => setCurrentView('home')} 
          onOrderCompleted={handleOrderCompleted}
        />;
      case 'tracking':
        return <OrderTracking 
          onBack={() => setCurrentView('home')} 
          initialSearchId={trackingOrderId}
        />;
      case 'admin':
        return <AdminDashboard onBack={() => setCurrentView('home')} />;
      default:
        return (
          <div className="min-h-screen bg-background p-8">
            <div className="container max-w-6xl mx-auto">
              <div className="text-center space-y-8">
                {/* Header */}
                <div className="space-y-4">
                  <div className="flex items-center justify-center space-x-2">
                    <FileText className="h-8 w-8 text-primary" />
                    <h1 className="text-4xl">CampusPrint</h1>
                  </div>
                  <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                    Digital xerox management system for colleges. Upload documents online, skip the queues, and track your orders in real-time.
                  </p>
                </div>

                {/* Quick Stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
                  <div className="p-4 bg-primary/5 rounded-lg">
                    <div className="flex items-center justify-center space-x-2">
                      <FileText className="h-5 w-5 text-primary" />
                      <div className="text-center">
                        <p className="text-lg font-bold">{state.stats.todayOrders}</p>
                        <p className="text-xs text-muted-foreground">Orders Today</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg">
                    <div className="flex items-center justify-center space-x-2">
                      <Clock className="h-5 w-5 text-green-600" />
                      <div className="text-center">
                        <p className="text-lg font-bold">{state.stats.avgWaitTime}</p>
                        <p className="text-xs text-muted-foreground">Avg Wait</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center justify-center space-x-2">
                      <Users className="h-5 w-5 text-blue-600" />
                      <div className="text-center">
                        <p className="text-lg font-bold">{state.stats.activeShops}</p>
                        <p className="text-xs text-muted-foreground">Active Shops</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-4 bg-yellow-50 rounded-lg">
                    <div className="flex items-center justify-center space-x-2">
                      <CheckCircle className="h-5 w-5 text-yellow-600" />
                      <div className="text-center">
                        <p className="text-lg font-bold">{state.stats.satisfaction}/5</p>
                        <p className="text-xs text-muted-foreground">Rating</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Main Actions */}
                <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
                  <Card className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Upload className="h-5 w-5" />
                        <span>Upload Documents</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">
                        Upload your documents online and select printing options. No more waiting in lines!
                      </p>
                      <Button 
                        className="w-full" 
                        onClick={() => setCurrentView('upload')}
                      >
                        Start Upload
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Search className="h-5 w-5" />
                        <span>Track Orders</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">
                        Real-time order tracking and notifications for your print jobs with live queue status.
                      </p>
                      <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={() => handleTrackOrder()}
                      >
                        Track Order
                      </Button>
                    </CardContent>
                  </Card>
                </div>

                {/* Live Queue Status */}
                <div className="max-w-4xl mx-auto">
                  <h2 className="text-2xl mb-6">Live Queue Status</h2>
                  <div className="grid md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-medium">Central Library Xerox</h3>
                          <Badge variant="default">Low Queue</Badge>
                        </div>
                        <div className="space-y-1 text-sm text-muted-foreground">
                          <p>🚶‍♂️ 2 min walk from main gate</p>
                          <p>⏱️ Current wait: ~2 minutes</p>
                          <p>📋 3 orders in queue</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-medium">Engineering Block Prints</h3>
                          <Badge variant="secondary">Medium Queue</Badge>
                        </div>
                        <div className="space-y-1 text-sm text-muted-foreground">
                          <p>🚶‍♂️ 5 min walk from main gate</p>
                          <p>⏱️ Current wait: ~8 minutes</p>
                          <p>📋 7 orders in queue</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-medium">Commerce Building Copy</h3>
                          <Badge variant="destructive">High Queue</Badge>
                        </div>
                        <div className="space-y-1 text-sm text-muted-foreground">
                          <p>🚶‍♂️ 8 min walk from main gate</p>
                          <p>⏱️ Current wait: ~15 minutes</p>
                          <p>📋 12 orders in queue</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>


              </div>
            </div>
          </div>
        );
    }
  };

  return renderCurrentView();
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
      <Toaster position="top-right" />
    </AppProvider>
  );
}