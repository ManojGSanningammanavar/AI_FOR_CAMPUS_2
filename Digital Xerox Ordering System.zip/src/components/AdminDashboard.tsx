import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { ArrowLeft, BarChart3, Users, FileText, Clock, TrendingUp, CheckCircle, AlertTriangle } from 'lucide-react';
import { useApp, Order } from '../contexts/AppContext';
import { toast } from 'sonner';

interface AdminDashboardProps {
  onBack: () => void;
}

const weeklyStats = {
  totalOrders: 247,
  totalRevenue: 18420,
  avgOrderValue: 74.6,
  completionRate: 94.3,
  customerSatisfaction: 4.6
};

export function AdminDashboard({ onBack }: AdminDashboardProps) {
  const [selectedTab, setSelectedTab] = useState('overview');
  const { state, updateOrderStatus } = useApp();
  
  const todayOrders = state.orders;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline">Pending</Badge>;
      case 'processing':
        return <Badge className="bg-blue-100 text-blue-800">Processing</Badge>;
      case 'ready':
        return <Badge className="bg-green-100 text-green-800">Ready</Badge>;
      case 'completed':
        return <Badge variant="secondary">Completed</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const handleUpdateOrderStatus = (orderId: string, newStatus: Order['status']) => {
    updateOrderStatus(orderId, newStatus);
    toast.success(`Order ${orderId} updated to ${newStatus}`);
  };

  return (
    <div className="container py-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center space-x-4 mb-8">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1>Admin Dashboard</h1>
            <p className="text-muted-foreground">Central Library Xerox - Manage orders and monitor performance</p>
          </div>
        </div>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Today's Orders</p>
                      <p className="text-2xl font-bold">23</p>
                    </div>
                    <FileText className="h-8 w-8 text-primary" />
                  </div>
                  <p className="text-xs text-green-600 mt-2">+12% from yesterday</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Revenue</p>
                      <p className="text-2xl font-bold">₹1,840</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-green-500" />
                  </div>
                  <p className="text-xs text-green-600 mt-2">+8% from yesterday</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Queue Length</p>
                      <p className="text-2xl font-bold">3</p>
                    </div>
                    <Clock className="h-8 w-8 text-blue-500" />
                  </div>
                  <p className="text-xs text-blue-600 mt-2">2 min avg wait</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Active Users</p>
                      <p className="text-2xl font-bold">156</p>
                    </div>
                    <Users className="h-8 w-8 text-purple-500" />
                  </div>
                  <p className="text-xs text-purple-600 mt-2">Online now</p>
                </CardContent>
              </Card>
            </div>

            {/* Current Queue */}
            <Card>
              <CardHeader>
                <CardTitle>Current Processing Queue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {todayOrders.filter(order => ['pending', 'processing'].includes(order.status)).map((order, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium">{index + 1}</span>
                        </div>
                        <div>
                          <p className="font-medium">{order.id}</p>
                          <p className="text-sm text-muted-foreground">{order.studentName} • {order.copies} copies</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        {getStatusBadge(order.status)}
                        <div className="flex space-x-2">
                          {order.status === 'pending' && (
                            <Button size="sm" onClick={() => handleUpdateOrderStatus(order.id, 'processing')}>
                              Start
                            </Button>
                          )}
                          {order.status === 'processing' && (
                            <Button size="sm" onClick={() => handleUpdateOrderStatus(order.id, 'ready')}>
                              Complete
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  {todayOrders.filter(order => ['pending', 'processing'].includes(order.status)).length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      <CheckCircle className="h-12 w-12 mx-auto mb-4" />
                      <p>No orders in queue. All caught up!</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Weekly Performance */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Weekly Performance</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Order Completion Rate</span>
                      <span className="text-sm font-medium">{weeklyStats.completionRate}%</span>
                    </div>
                    <Progress value={weeklyStats.completionRate} />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Customer Satisfaction</span>
                      <span className="text-sm font-medium">{weeklyStats.customerSatisfaction}/5.0</span>
                    </div>
                    <Progress value={(weeklyStats.customerSatisfaction / 5) * 100} />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 pt-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Orders</p>
                      <p className="text-xl font-bold">{weeklyStats.totalOrders}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Avg Order Value</p>
                      <p className="text-xl font-bold">₹{weeklyStats.avgOrderValue}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>System Alerts</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start space-x-3 p-3 bg-yellow-50 rounded-lg">
                    <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-yellow-800">Paper Running Low</p>
                      <p className="text-xs text-yellow-600">A4 paper: 15% remaining</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
                    <Clock className="h-5 w-5 text-blue-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-blue-800">Peak Hours Approaching</p>
                      <p className="text-xs text-blue-600">High order volume expected 2-4 PM</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3 p-3 bg-green-50 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-green-800">System Status: Good</p>
                      <p className="text-xs text-green-600">All printers operational</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="orders" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Today's Orders</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Order ID</TableHead>
                      <TableHead>Student</TableHead>
                      <TableHead>Files</TableHead>
                      <TableHead>Copies</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Time</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {todayOrders.slice(0, 10).map((order, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-mono">{order.id}</TableCell>
                        <TableCell>{order.studentName}</TableCell>
                        <TableCell>{order.files.length}</TableCell>
                        <TableCell>{order.copies}</TableCell>
                        <TableCell>{getStatusBadge(order.status)}</TableCell>
                        <TableCell>{order.submittedAt.split(' ')[1]} {order.submittedAt.split(' ')[2]}</TableCell>
                        <TableCell>₹{order.total}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            {order.status === 'pending' && (
                              <Button size="sm" variant="outline" onClick={() => handleUpdateOrderStatus(order.id, 'processing')}>
                                Start
                              </Button>
                            )}
                            {order.status === 'processing' && (
                              <Button size="sm" variant="outline" onClick={() => handleUpdateOrderStatus(order.id, 'ready')}>
                                Complete
                              </Button>
                            )}
                            {order.status === 'ready' && (
                              <Button size="sm" variant="outline" onClick={() => handleUpdateOrderStatus(order.id, 'completed')}>
                                Mark Collected
                              </Button>
                            )}
                            <Button size="sm" variant="ghost" onClick={() => toast.info(`Viewing order ${order.id}`)}>
                              View
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Revenue Trends</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center bg-muted/30 rounded-lg">
                    <p className="text-muted-foreground">Revenue chart would go here</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Order Volume</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center bg-muted/30 rounded-lg">
                    <p className="text-muted-foreground">Order volume chart would go here</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Printer Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <p className="text-sm font-medium">Pricing</p>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs text-muted-foreground">B&W per page</label>
                      <div className="flex items-center space-x-2">
                        <span>₹</span>
                        <input type="number" defaultValue="2" className="w-20 p-1 border rounded" />
                      </div>
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground">Color per page</label>
                      <div className="flex items-center space-x-2">
                        <span>₹</span>
                        <input type="number" defaultValue="6" className="w-20 p-1 border rounded" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm font-medium">Operating Hours</p>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs text-muted-foreground">Open</label>
                      <input type="time" defaultValue="08:00" className="w-full p-1 border rounded" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground">Close</label>
                      <input type="time" defaultValue="20:00" className="w-full p-1 border rounded" />
                    </div>
                  </div>
                </div>

                <Button onClick={() => toast.success('Settings saved successfully!')}>Save Settings</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}