import { Card, CardContent } from './ui/card';
import { Upload, Clock, CreditCard, Bell, MapPin, Shield } from 'lucide-react';

const features = [
  {
    icon: Upload,
    title: "Easy Upload",
    description: "Drag and drop your documents or browse from your device. Support for PDF, DOC, and image files."
  },
  {
    icon: Clock,
    title: "Time Slots",
    description: "Book pickup or delivery slots that work with your schedule. Real-time availability updates."
  },
  {
    icon: CreditCard,
    title: "Digital Payments",
    description: "Pay securely online with UPI, cards, or campus wallet. No more handling cash at the counter."
  },
  {
    icon: Bell,
    title: "Smart Notifications",
    description: "Get instant updates when your order is ready, delayed, or completed via SMS and app notifications."
  },
  {
    icon: MapPin,
    title: "Multiple Locations",
    description: "Choose from various xerox shops across campus. Find the nearest or least busy location."
  },
  {
    icon: Shield,
    title: "Secure & Private",
    description: "Your documents are encrypted and automatically deleted after printing. Complete privacy guaranteed."
  }
];

export function Features() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-3xl lg:text-4xl">
            Everything you need for hassle-free printing
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Our comprehensive solution eliminates queues and makes campus printing as easy as ordering food online.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="border-0 shadow-sm bg-white/50 backdrop-blur">
              <CardContent className="p-6">
                <div className="mb-4">
                  <feature.icon className="h-12 w-12 text-primary" />
                </div>
                <h3 className="mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <div className="inline-flex items-center px-4 py-2 bg-primary/10 text-primary rounded-full">
            <span className="text-sm">✨ Coming Soon: AI-powered document optimization and cloud storage integration</span>
          </div>
        </div>
      </div>
    </section>
  );
}