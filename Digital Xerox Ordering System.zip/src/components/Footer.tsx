import { FileText, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-muted/30 mt-20">
      <div className="container py-12">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <FileText className="h-6 w-6 text-primary" />
              <span className="font-bold text-lg">CampusPrint</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Revolutionizing campus printing with smart queue management and digital convenience.
            </p>
          </div>
          
          <div className="space-y-4">
            <h4>Quick Links</h4>
            <div className="space-y-2 text-sm">
              <p><a href="#" className="text-muted-foreground hover:text-foreground">How it Works</a></p>
              <p><a href="#" className="text-muted-foreground hover:text-foreground">Pricing</a></p>
              <p><a href="#" className="text-muted-foreground hover:text-foreground">Locations</a></p>
              <p><a href="#" className="text-muted-foreground hover:text-foreground">Support</a></p>
            </div>
          </div>
          
          <div className="space-y-4">
            <h4>For Students</h4>
            <div className="space-y-2 text-sm">
              <p><a href="#" className="text-muted-foreground hover:text-foreground">Upload Documents</a></p>
              <p><a href="#" className="text-muted-foreground hover:text-foreground">Track Orders</a></p>
              <p><a href="#" className="text-muted-foreground hover:text-foreground">Payment Methods</a></p>
              <p><a href="#" className="text-muted-foreground hover:text-foreground">Mobile App</a></p>
            </div>
          </div>
          
          <div className="space-y-4">
            <h4>Contact</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4" />
                <span>support@campusprint.edu</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4" />
                <span>+91 98765 43210</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4" />
                <span>Campus IT Services</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; 2024 CampusPrint. All rights reserved. | Privacy Policy | Terms of Service</p>
        </div>
      </div>
    </footer>
  );
}