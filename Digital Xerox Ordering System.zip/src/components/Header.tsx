import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { FileText, BarChart3, Upload, Search, UserCheck } from 'lucide-react';

interface HeaderProps {
  currentView: 'home' | 'upload' | 'tracking' | 'admin';
  setCurrentView: (view: 'home' | 'upload' | 'tracking' | 'admin') => void;
  userRole: 'student' | 'admin';
  setUserRole: (role: 'student' | 'admin') => void;
}

export function Header({ currentView, setCurrentView, userRole, setUserRole }: HeaderProps) {
  return (
    <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center space-x-2">
          <FileText className="h-8 w-8 text-primary" />
          <span className="font-bold text-xl">CampusPrint</span>
          <Badge variant="secondary">Beta</Badge>
        </div>
        
        <nav className="hidden md:flex items-center space-x-6">
          <Button
            variant={currentView === 'home' ? 'default' : 'ghost'}
            onClick={() => setCurrentView('home')}
            className="flex items-center space-x-2"
          >
            <span>Home</span>
          </Button>
          
          <Button
            variant={currentView === 'upload' ? 'default' : 'ghost'}
            onClick={() => setCurrentView('upload')}
            className="flex items-center space-x-2"
          >
            <Upload className="h-4 w-4" />
            <span>Upload</span>
          </Button>
          
          <Button
            variant={currentView === 'tracking' ? 'default' : 'ghost'}
            onClick={() => setCurrentView('tracking')}
            className="flex items-center space-x-2"
          >
            <Search className="h-4 w-4" />
            <span>Track Order</span>
          </Button>
          
          {userRole === 'admin' && (
            <Button
              variant={currentView === 'admin' ? 'default' : 'ghost'}
              onClick={() => setCurrentView('admin')}
              className="flex items-center space-x-2"
            >
              <BarChart3 className="h-4 w-4" />
              <span>Dashboard</span>
            </Button>
          )}
        </nav>

        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setUserRole(userRole === 'student' ? 'admin' : 'student')}
            className="flex items-center space-x-2"
          >
            <UserCheck className="h-4 w-4" />
            <span>{userRole === 'student' ? 'Student' : 'Admin'}</span>
          </Button>
        </div>
      </div>
    </header>
  );
}