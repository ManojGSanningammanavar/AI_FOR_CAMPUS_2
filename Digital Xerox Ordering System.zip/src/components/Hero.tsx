import { Button } from './ui/button';
import { ArrowRight, Clock, CreditCard, Smartphone, FileText } from 'lucide-react';

interface HeroProps {
  onGetStarted: () => void;
}

export function Hero({ onGetStarted }: HeroProps) {
  return (
    <section className="relative py-20 lg:py-32 overflow-hidden">
      <div className="container">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-6">
              <h1 className="text-4xl lg:text-6xl tracking-tight">
                Skip the Queue,
                <span className="text-primary block">Print Smart</span>
              </h1>
              <p className="text-xl text-muted-foreground max-w-lg">
                Upload documents online, select your time slot, and pick up your prints without waiting. The future of campus printing is here.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" onClick={onGetStarted} className="flex items-center space-x-2">
                <span>Start Printing</span>
                <ArrowRight className="h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg">
                Watch Demo
              </Button>
            </div>
            
            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="text-center">
                <Clock className="h-8 w-8 text-primary mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">Save Time</p>
              </div>
              <div className="text-center">
                <CreditCard className="h-8 w-8 text-primary mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">Digital Payments</p>
              </div>
              <div className="text-center">
                <Smartphone className="h-8 w-8 text-primary mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">Mobile Ready</p>
              </div>
            </div>
          </div>
          
          <div className="relative lg:order-last">
            <div className="relative bg-muted/30 rounded-2xl h-64 lg:h-96 flex items-center justify-center">
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-primary/10 rounded-full mx-auto flex items-center justify-center">
                  <FileText className="h-8 w-8 text-primary" />
                </div>
                <p className="text-muted-foreground">Campus Printing Made Easy</p>
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg border">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm">Live Queue: 2 min wait</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}