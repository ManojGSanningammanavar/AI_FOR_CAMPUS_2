import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ArrowLeft, Search, Clock, CheckCircle, Truck, FileText, AlertCircle } from 'lucide-react';
import { useApp, Order } from '../contexts/AppContext';

interface OrderTrackingProps {
  onBack: () => void;
  initialSearchId?: string;
}

export function OrderTracking({ onBack, initialSearchId }: OrderTrackingProps) {
  const [searchId, setSearchId] = useState(initialSearchId || '');
  const [searchResult, setSearchResult] = useState<Order | null>(null);
  const { state, getOrder } = useApp();

  const handleSearch = () => {
    const order = getOrder(searchId);
    setSearchResult(order || null);
  };

  // Auto-search if initial order ID is provided
  useEffect(() => {
    if (initialSearchId) {
      handleSearch();
    }
  }, [initialSearchId]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'processing':
        return <Clock className="h-5 w-5 text-blue-500" />;
      case 'ready':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-gray-500" />;
      default:
        return <AlertCircle className="h-5 w-5 text-yellow-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'processing':
        return <Badge className="bg-blue-100 text-blue-800">Processing</Badge>;
      case 'ready':
        return <Badge className="bg-green-100 text-green-800">Ready for Pickup</Badge>;
      case 'completed':
        return <Badge variant="secondary">Completed</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getProgressValue = (status: string) => {
    switch (status) {
      case 'processing':
        return 50;
      case 'ready':
        return 75;
      case 'completed':
        return 100;
      default:
        return 25;
    }
  };

  return (
    <div className="container py-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center space-x-4 mb-8">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1>Track Your Order</h1>
        </div>

        <div className="space-y-8">
          {/* Search Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Search className="h-5 w-5" />
                <span>Search by Order ID</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-4">
                <div className="flex-1">
                  <Label htmlFor="orderid">Order ID</Label>
                  <Input
                    id="orderid"
                    placeholder="Enter your order ID (e.g., CP123456)"
                    value={searchId}
                    onChange={(e) => setSearchId(e.target.value)}
                  />
                </div>
                <div className="flex items-end">
                  <Button onClick={handleSearch} disabled={!searchId}>
                    <Search className="h-4 w-4 mr-2" />
                    Search
                  </Button>
                </div>
              </div>

              {searchResult === null && searchId && (
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-yellow-800">Order not found. Please check your order ID.</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Search Result */}
          {searchResult && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Order {searchResult.id}</CardTitle>
                  {getStatusBadge(searchResult.status)}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center space-x-4">
                  {getStatusIcon(searchResult.status)}
                  <div className="flex-1">
                    <Progress value={getProgressValue(searchResult.status)} className="mb-2" />
                    <p className="text-sm text-muted-foreground">
                      {searchResult.status === 'processing' && `Estimated completion: ${searchResult.estimatedCompletion}`}
                      {searchResult.status === 'ready' && `Ready since ${searchResult.readyAt}`}
                      {searchResult.status === 'completed' && `Completed at ${searchResult.completedAt}`}
                    </p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <h4>Order Details</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Files:</span>
                        <span>{searchResult.files.join(', ')}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Copies:</span>
                        <span>{searchResult.copies}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Total:</span>
                        <span>₹{searchResult.total}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Time Slot:</span>
                        <span>{searchResult.timeSlot}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4>Location & Timeline</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Location:</span>
                        <span>{searchResult.location}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Submitted:</span>
                        <span>{searchResult.submittedAt}</span>
                      </div>
                      {searchResult.readyAt && (
                        <div className="flex justify-between">
                          <span>Ready:</span>
                          <span>{searchResult.readyAt}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {searchResult.status === 'ready' && (
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <span className="text-green-800">Your order is ready for pickup!</span>
                    </div>
                    <p className="text-sm text-green-600 mt-1">
                      Please collect from {searchResult.location} with your order ID.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Recent Orders */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Orders</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {state.orders.slice(0, 5).map((order, index) => (
                <div 
                  key={index} 
                  className="flex items-center justify-between p-4 border rounded-lg cursor-pointer hover:bg-muted/30"
                  onClick={() => {
                    setSearchId(order.id);
                    setSearchResult(order);
                  }}
                >
                  <div className="flex items-center space-x-4">
                    {getStatusIcon(order.status)}
                    <div>
                      <p className="font-medium">{order.id}</p>
                      <p className="text-sm text-muted-foreground">
                        {order.files.length} file(s) • {order.copies} copies • {order.location}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    {getStatusBadge(order.status)}
                    <p className="text-sm text-muted-foreground mt-1">₹{order.total}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Live Queue Status */}
          <Card>
            <CardHeader>
              <CardTitle>Live Queue Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg">
                  <h4>Central Library Xerox</h4>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-sm text-muted-foreground">Current wait:</span>
                    <Badge variant="default">2 min</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">3 orders in queue</p>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <h4>Engineering Block Prints</h4>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-sm text-muted-foreground">Current wait:</span>
                    <Badge variant="secondary">8 min</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">7 orders in queue</p>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <h4>Commerce Building Copy</h4>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-sm text-muted-foreground">Current wait:</span>
                    <Badge variant="destructive">15 min</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">12 orders in queue</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}