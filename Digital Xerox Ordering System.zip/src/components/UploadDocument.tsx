import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ArrowLeft, Upload, FileText, Calendar, CreditCard, CheckCircle } from 'lucide-react';
import { useApp } from '../contexts/AppContext';

interface UploadDocumentProps {
  onBack: () => void;
  onOrderCompleted: (orderId: string) => void;
}

export function UploadDocument({ onBack, onOrderCompleted }: UploadDocumentProps) {
  const [step, setStep] = useState(1);
  const [files, setFiles] = useState<File[]>([]);
  const [completedOrderId, setCompletedOrderId] = useState<string>('');
  const [orderDetails, setOrderDetails] = useState({
    copies: 1,
    paperSize: '',
    colorType: '',
    binding: false,
    delivery: '',
    timeSlot: '',
    location: '',
    specialInstructions: ''
  });
  const { addOrder } = useApp();

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      setFiles(Array.from(event.target.files));
    }
  };

  const timeSlots = [
    '9:00 AM - 10:00 AM',
    '10:00 AM - 11:00 AM',
    '11:00 AM - 12:00 PM',
    '12:00 PM - 1:00 PM',
    '2:00 PM - 3:00 PM',
    '3:00 PM - 4:00 PM',
    '4:00 PM - 5:00 PM'
  ];

  const locations = [
    { name: 'Central Library Xerox', distance: '2 min walk', queue: 'Low' },
    { name: 'Engineering Block Prints', distance: '5 min walk', queue: 'Medium' },
    { name: 'Commerce Building Copy Center', distance: '8 min walk', queue: 'High' }
  ];

  const calculateTotal = () => {
    const basePrice = orderDetails.copies * 2; // ₹2 per page
    const colorMultiplier = orderDetails.colorType === 'color' ? 3 : 1;
    const bindingCost = orderDetails.binding ? 20 : 0;
    const deliveryCost = orderDetails.delivery === 'delivery' ? 25 : 0;
    return (basePrice * colorMultiplier) + bindingCost + deliveryCost;
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Upload className="h-5 w-5" />
                <span>Upload Documents</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
                <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <div className="space-y-2">
                  <p>Drag and drop your files here, or click to browse</p>
                  <p className="text-sm text-muted-foreground">
                    Supports PDF, DOC, DOCX, JPG, PNG (Max 10MB per file)
                  </p>
                </div>
                <Input
                  type="file"
                  multiple
                  accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                  onChange={handleFileUpload}
                  className="mt-4"
                />
              </div>
              
              {files.length > 0 && (
                <div className="space-y-2">
                  <Label>Uploaded Files:</Label>
                  {files.map((file, index) => (
                    <div key={index} className="flex items-center space-x-2 p-2 bg-muted rounded">
                      <FileText className="h-4 w-4" />
                      <span className="text-sm">{file.name}</span>
                      <Badge variant="secondary">{(file.size / 1024 / 1024).toFixed(1)} MB</Badge>
                    </div>
                  ))}
                </div>
              )}
              
              <Button 
                onClick={() => setStep(2)} 
                disabled={files.length === 0}
                className="w-full"
              >
                Continue to Details
              </Button>
            </CardContent>
          </Card>
        );

      case 2:
        return (
          <Card>
            <CardHeader>
              <CardTitle>Print Options</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="copies">Number of Copies</Label>
                  <Input
                    id="copies"
                    type="number"
                    min="1"
                    max="500"
                    value={orderDetails.copies}
                    onChange={(e) => setOrderDetails({...orderDetails, copies: parseInt(e.target.value) || 1})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Paper Size</Label>
                  <Select value={orderDetails.paperSize} onValueChange={(value) => setOrderDetails({...orderDetails, paperSize: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select paper size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="a4">A4 (Standard)</SelectItem>
                      <SelectItem value="a3">A3 (Large)</SelectItem>
                      <SelectItem value="letter">Letter</SelectItem>
                      <SelectItem value="legal">Legal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-3">
                <Label>Color Options</Label>
                <RadioGroup value={orderDetails.colorType} onValueChange={(value) => setOrderDetails({...orderDetails, colorType: value})}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="bw" id="bw" />
                    <Label htmlFor="bw">Black & White (₹2 per page)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="color" id="color" />
                    <Label htmlFor="color">Color (₹6 per page)</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="binding" 
                  checked={orderDetails.binding}
                  onCheckedChange={(checked) => setOrderDetails({...orderDetails, binding: checked as boolean})}
                />
                <Label htmlFor="binding">Spiral Binding (+₹20)</Label>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="instructions">Special Instructions (Optional)</Label>
                <Textarea
                  id="instructions"
                  placeholder="Any special requirements for your print job..."
                  value={orderDetails.specialInstructions}
                  onChange={(e) => setOrderDetails({...orderDetails, specialInstructions: e.target.value})}
                />
              </div>
              
              <Button onClick={() => setStep(3)} className="w-full">
                Continue to Scheduling
              </Button>
            </CardContent>
          </Card>
        );

      case 3:
        return (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="h-5 w-5" />
                <span>Schedule & Location</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label>Delivery Method</Label>
                <RadioGroup value={orderDetails.delivery} onValueChange={(value) => setOrderDetails({...orderDetails, delivery: value})}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="pickup" id="pickup" />
                    <Label htmlFor="pickup">Pickup (Free)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="delivery" id="delivery" />
                    <Label htmlFor="delivery">Campus Delivery (+₹25)</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="space-y-3">
                <Label>Choose Location</Label>
                <div className="space-y-3">
                  {locations.map((location, index) => (
                    <div 
                      key={index}
                      className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                        orderDetails.location === location.name ? 'border-primary bg-primary/5' : 'hover:border-muted-foreground'
                      }`}
                      onClick={() => setOrderDetails({...orderDetails, location: location.name})}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p>{location.name}</p>
                          <p className="text-sm text-muted-foreground">{location.distance}</p>
                        </div>
                        <Badge variant={location.queue === 'Low' ? 'default' : location.queue === 'Medium' ? 'secondary' : 'destructive'}>
                          {location.queue} Queue
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="space-y-3">
                <Label>Time Slot</Label>
                <Select value={orderDetails.timeSlot} onValueChange={(value) => setOrderDetails({...orderDetails, timeSlot: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select preferred time" />
                  </SelectTrigger>
                  <SelectContent>
                    {timeSlots.map((slot, index) => (
                      <SelectItem key={index} value={slot}>{slot}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <Button onClick={() => setStep(4)} className="w-full">
                Continue to Payment
              </Button>
            </CardContent>
          </Card>
        );

      case 4:
        return (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <CreditCard className="h-5 w-5" />
                <span>Payment & Confirmation</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-muted p-4 rounded-lg space-y-2">
                <h3>Order Summary</h3>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Pages ({orderDetails.copies} copies)</span>
                    <span>₹{orderDetails.copies * 2}</span>
                  </div>
                  {orderDetails.colorType === 'color' && (
                    <div className="flex justify-between">
                      <span>Color printing (3x)</span>
                      <span>₹{orderDetails.copies * 4}</span>
                    </div>
                  )}
                  {orderDetails.binding && (
                    <div className="flex justify-between">
                      <span>Spiral binding</span>
                      <span>₹20</span>
                    </div>
                  )}
                  {orderDetails.delivery === 'delivery' && (
                    <div className="flex justify-between">
                      <span>Campus delivery</span>
                      <span>₹25</span>
                    </div>
                  )}
                  <div className="border-t pt-1 flex justify-between font-medium">
                    <span>Total</span>
                    <span>₹{calculateTotal()}</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <Label>Payment Method</Label>
                <div className="grid grid-cols-2 gap-3">
                  <Button variant="outline" className="h-12">UPI</Button>
                  <Button variant="outline" className="h-12">Card</Button>
                  <Button variant="outline" className="h-12">Campus Wallet</Button>
                  <Button variant="outline" className="h-12">Net Banking</Button>
                </div>
              </div>
              
              <Button onClick={() => {
                // Create the order
                const orderId = addOrder({
                  files: files.map(f => f.name),
                  copies: orderDetails.copies,
                  total: calculateTotal(),
                  location: orderDetails.location,
                  timeSlot: orderDetails.timeSlot,
                  paperSize: orderDetails.paperSize,
                  colorType: orderDetails.colorType,
                  binding: orderDetails.binding,
                  delivery: orderDetails.delivery,
                  specialInstructions: orderDetails.specialInstructions
                });
                setCompletedOrderId(orderId);
                setStep(5);
              }} className="w-full">
                Pay ₹{calculateTotal()} & Place Order
              </Button>
            </CardContent>
          </Card>
        );

      case 5:
        return (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-green-600">
                <CheckCircle className="h-5 w-5" />
                <span>Order Confirmed!</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6 text-center">
              <div className="p-6 bg-green-50 rounded-lg">
                <h3 className="text-green-800">Order #{completedOrderId}</h3>
                <p className="text-green-600">Your documents are being processed</p>
              </div>
              
              <div className="space-y-2">
                <p>📱 SMS confirmation sent to your registered mobile</p>
                <p>⏰ Expected ready time: {orderDetails.timeSlot}</p>
                <p>📍 Location: {orderDetails.location}</p>
              </div>
              
              <div className="flex gap-4">
                <Button onClick={onBack} className="flex-1">
                  Place Another Order
                </Button>
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => onOrderCompleted(completedOrderId)}
                >
                  Track This Order
                </Button>
              </div>
            </CardContent>
          </Card>
        );

      default:
        return null;
    }
  };

  return (
    <div className="container py-8">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center space-x-4 mb-8">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1">
            <h1>Upload Document</h1>
            <Progress value={(step / 5) * 100} className="mt-2" />
          </div>
        </div>
        
        {renderStep()}
      </div>
    </div>
  );
}