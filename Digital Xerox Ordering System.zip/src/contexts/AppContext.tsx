import { createContext, useContext, useState, ReactNode } from 'react';

export interface Order {
  id: string;
  status: 'pending' | 'processing' | 'ready' | 'completed';
  files: string[];
  copies: number;
  total: number;
  location: string;
  submittedAt: string;
  timeSlot: string;
  studentName?: string;
  paperSize: string;
  colorType: string;
  binding: boolean;
  delivery: string;
  specialInstructions?: string;
  completedAt?: string;
  readyAt?: string;
  estimatedCompletion?: string;
}

interface AppState {
  orders: Order[];
  currentUser: {
    name: string;
    phone: string;
    email: string;
  };
  stats: {
    todayOrders: number;
    totalRevenue: number;
    avgWaitTime: string;
    activeShops: number;
    satisfaction: number;
  };
}

interface AppContextType {
  state: AppState;
  addOrder: (order: Omit<Order, 'id' | 'submittedAt' | 'status'>) => string;
  updateOrderStatus: (orderId: string, status: Order['status'], additionalData?: Partial<Order>) => void;
  getOrder: (orderId: string) => Order | undefined;
  getUserOrders: () => Order[];
  updateStats: (newStats: Partial<AppState['stats']>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Mock initial data
const initialOrders: Order[] = [
  {
    id: 'CP123456',
    status: 'completed',
    files: ['Assignment_1.pdf', 'Notes.docx'],
    copies: 5,
    total: 85,
    location: 'Central Library Xerox',
    submittedAt: '2024-01-15 09:30 AM',
    completedAt: '2024-01-15 10:15 AM',
    timeSlot: '10:00 AM - 11:00 AM',
    studentName: 'Rahul Sharma',
    paperSize: 'a4',
    colorType: 'color',
    binding: true,
    delivery: 'pickup'
  },
  {
    id: 'CP789012',
    status: 'processing',
    files: ['Presentation.pdf'],
    copies: 20,
    total: 140,
    location: 'Engineering Block Prints',
    submittedAt: '2024-01-15 11:45 AM',
    timeSlot: '12:00 PM - 1:00 PM',
    estimatedCompletion: '12:30 PM',
    studentName: 'Priya Patel',
    paperSize: 'a4',
    colorType: 'color',
    binding: false,
    delivery: 'pickup'
  },
  {
    id: 'CP345678',
    status: 'ready',
    files: ['Research_Paper.pdf'],
    copies: 3,
    total: 36,
    location: 'Commerce Building Copy Center',
    submittedAt: '2024-01-15 08:15 AM',
    readyAt: '2024-01-15 09:00 AM',
    timeSlot: '9:00 AM - 10:00 AM',
    studentName: 'Amit Kumar',
    paperSize: 'a4',
    colorType: 'bw',
    binding: false,
    delivery: 'pickup'
  }
];

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>({
    orders: initialOrders,
    currentUser: {
      name: 'Current Student',
      phone: '+91 9876543210',
      email: 'student@college.edu'
    },
    stats: {
      todayOrders: 23,
      totalRevenue: 1840,
      avgWaitTime: '2 min',
      activeShops: 3,
      satisfaction: 4.6
    }
  });

  const addOrder = (orderData: Omit<Order, 'id' | 'submittedAt' | 'status'>): string => {
    const newOrderId = `CP${Date.now().toString().slice(-6)}`;
    const newOrder: Order = {
      ...orderData,
      id: newOrderId,
      status: 'pending',
      submittedAt: new Date().toLocaleString('en-IN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      }),
      studentName: state.currentUser.name
    };

    setState(prev => ({
      ...prev,
      orders: [newOrder, ...prev.orders],
      stats: {
        ...prev.stats,
        todayOrders: prev.stats.todayOrders + 1,
        totalRevenue: prev.stats.totalRevenue + orderData.total
      }
    }));

    return newOrderId;
  };

  const updateOrderStatus = (orderId: string, status: Order['status'], additionalData?: Partial<Order>) => {
    setState(prev => ({
      ...prev,
      orders: prev.orders.map(order => {
        if (order.id === orderId) {
          const updatedOrder = { ...order, status, ...additionalData };
          
          // Set timestamps based on status
          if (status === 'ready' && !updatedOrder.readyAt) {
            updatedOrder.readyAt = new Date().toLocaleString('en-IN', {
              year: 'numeric',
              month: '2-digit',
              day: '2-digit',
              hour: '2-digit',
              minute: '2-digit',
              hour12: true
            });
          } else if (status === 'completed' && !updatedOrder.completedAt) {
            updatedOrder.completedAt = new Date().toLocaleString('en-IN', {
              year: 'numeric',
              month: '2-digit',
              day: '2-digit',
              hour: '2-digit',
              minute: '2-digit',
              hour12: true
            });
          } else if (status === 'processing' && !updatedOrder.estimatedCompletion) {
            const estimated = new Date();
            estimated.setMinutes(estimated.getMinutes() + 15);
            updatedOrder.estimatedCompletion = estimated.toLocaleTimeString('en-IN', {
              hour: '2-digit',
              minute: '2-digit',
              hour12: true
            });
          }
          
          return updatedOrder;
        }
        return order;
      })
    }));
  };

  const getOrder = (orderId: string): Order | undefined => {
    return state.orders.find(order => order.id === orderId);
  };

  const getUserOrders = (): Order[] => {
    return state.orders.filter(order => order.studentName === state.currentUser.name);
  };

  const updateStats = (newStats: Partial<AppState['stats']>) => {
    setState(prev => ({
      ...prev,
      stats: { ...prev.stats, ...newStats }
    }));
  };

  return (
    <AppContext.Provider value={{
      state,
      addOrder,
      updateOrderStatus,
      getOrder,
      getUserOrders,
      updateStats
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}